#include "bsp_epit.h"
#include "bsp_int.h"
#include "bsp_led.h"
#include "bsp_gpio.h"

/*
 * @description	: 初始化epit定时器
 * @param - frac	:分频直
 * @param - val ：计数值
 * @return 		: 无
 */

void epit_init(uint32_t frac , uint32_t val){
    if(frac >4095){//限制分频
        frac = 4095;
    }
    /*配置CR寄存器*/
    volatile uint32_t temp = 0;
    EPIT1->CR = 0;
    temp |= (0xe << 0);
    temp |= (frac << 4);//加载分频值
    temp |= (1 << 17); //允许计数是写入新的技术值 方便按键消抖用
    temp |= (1 << 24); //选择外设时钟原为输入信号
    EPIT1->CR |= temp; //写入
    /*配置LR寄存器*/
    EPIT1->LR = val; //加载计数值
    /*配置CMPR寄存器*/
    EPIT1->CMPR = 0; //设置比较值 当 val-- == CMPR即触发中断
    /*初始化定时器中断并注册中断*/
    GIC_EnableIRQ(EPIT1_IRQn);
    system_register_irqhandler(EPIT1_IRQn , epit1_irqhandler , NULL);
    /*epit配置好后打开epit定时器*/
    //EPIT1->CR |= (1 << 0); 在按键中断中开启
}

/*
 * @description	: 定时器中断服务函数
 * @param - frac	:分频直
 * @param - val ：计数值
 * @return 		: 无
 */
void epit1_irqhandler(unsigned int gicciar , void *param){
    static uint32_t state = 1;
    if(gpio_pinread(GPIO1 , 18) == 0){//按键按下
        state ^= 1;
        led_switch(LED0 , state ,0);
    }
    /*清除中断标志位*/
    EPIT1->SR |= 1;
    EPIT1->CR &= ~(1 << 0);//关闭定时器
}