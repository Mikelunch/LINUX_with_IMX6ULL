#include "bsp_gpio.h"
/***************************************************************
Copyright © zuozhongkai Co., Ltd. 1998-2019. All rights reserved.
文件名	: 	 bsp_gpio.h
作者	   : 左忠凯
版本	   : V1.0
描述	   : GPIO操作文件。
其他	   : 无
论坛 	   : www.wtmembed.com
日志	   : 初版V1.0 2019/1/4 左忠凯创建
***************************************************************/

/*
 * @description		: GPIO初始化。
 * @param - base	: 要初始化的GPIO组。
 * @param - pin		: 要初始化GPIO在组内的编号。
 * @param - config	: GPIO配置结构体。
 * @return 			: 无
 */
void gpio_init(GPIO_Type *base, int pin, gpio_pin_config_t *config)
{
	if(config->direction == kGPIO_DigitalInput) /* 输入 */
	{
		base->GDIR &= ~( 1 << pin);
	}
	else										/* 输出 */
	{
		base->GDIR |= 1 << pin;
		gpio_pinwrite(base,pin, config->outputLogic);/* 设置默认输出电平 */
	}
	gpio_intconfig(base , pin , config->gpio_interrput_mode);
}

 /*
  * @description	 : 读取指定GPIO的电平值 。
  * @param - base	 : 要读取的GPIO组。
  * @param - pin	 : 要读取的GPIO脚号。
  * @return 		 : 无
  */
 int gpio_pinread(GPIO_Type *base, int pin)
 {
	 return (((base->DR) >> pin) & 0x1);
 }

 /*
  * @description	 : 指定GPIO输出高或者低电平 。
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @param - value	 : 要输出的电平，1 输出高电平， 0 输出低低电平
  * @return 		 : 无
  */
void gpio_pinwrite(GPIO_Type *base, int pin, int value)
{
	 if (value == 0U)
	 {
		 base->DR &= ~(1U << pin); /* 输出低电平 */
	 }
	 else
	 {
		 base->DR |= (1U << pin); /* 输出高电平 */
	 }
}

/*
  * @description	 : 使能GPIO中断函数
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @param - pin_enable	 : 使能或者关闭GPIO中断 1/0
  * @return 		 : 无
*/
void gpio_interrput_enable(GPIO_Type *base , int pin, int pin_enable){
	if(pin_enable){
		base->IMR |= 1 << pin;
	}
	else{
        base->IMR &= ~(1 << pin);
    }
}

/*
  * @description	 : 清除中断标志为
  * @param - base	 : 要清除的的GPIO组。
  * @param - pin	 : 要清除的GPIO脚号。注意置一是清除
  * @return 		 : 无
*/
void gpio_clearflag(GPIO_Type *base , int pin){
    base->ISR |= 1 << pin;
}

/*
  * @description	 : GPIO中断初始化
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @param - pin_mode	 : 中断触发模式
  * @return 		 : 无
*/
void gpio_intconfig(GPIO_Type *base , uint32_t pin ,gpio_interrupt_mode_t pin_mode){
	base->EDGE_SEL &= ~(1 << pin);//关闭任意边沿触发有效寄存器
	volatile uint32_t *icr; //IRC寄存器地址
	uint32_t icrShift = pin; //管脚偏移
	if(pin < 16){ //管脚是低16位的配置的寄存器是ICR1
		icr = &(base->ICR1);
	}
	else{
		icr = &(base->ICR2);
		icrShift -= 16;
	}
	if(pin_mode == BOTH_EDGES){ //双边沿触发
		base->EDGE_SEL |= (1 << pin);
	}
	else if(pin_mode == NO_INTERRUPT){//无触发
		return;
	}
	else{
		*icr &= ~(3 << (icrShift << 1)); //清零相关位
		*icr |= (pin_mode << (icrShift << 1));//配置相关位
	}
}