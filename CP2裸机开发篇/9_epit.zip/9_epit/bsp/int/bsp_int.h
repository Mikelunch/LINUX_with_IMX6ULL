#ifndef __BSP_INT_H__
#define __BSP_INT_H__

#include "imx6ul.h"
/*定义中断处理函数*/
typedef void (*system_irq_handler_t)(unsigned int gicciar , void *param);
/*中断处理函数结构体*/
typedef struct
{
    system_irq_handler_t irqhandler; //中断处理函数入口
    void *param;                     //传递进入中断处理函数的参数
}system_irq_handle_t;
void int_init(void);
void default_iqrhandler(unsigned int gicciar , void *param);//默认中断函数生成
void system_register_irqhandler(IRQn_Type irqn, system_irq_handler_t handler , void * parm); //中断函数注册
#endif // !__BSP_INT_H__


