# 实验9：定时器
**用定时器实现500msLED闪烁**
## EPIT简介
1.简介
2.选择 ipg_clk = 66Mhz 分频信号处理
3.工作模式
4.IMX6ULL有2个EPIT定时器

## EPIT寄存器简介
* EPIT_CR
* 


## 程序编写

## 利用epit实现按键消抖


