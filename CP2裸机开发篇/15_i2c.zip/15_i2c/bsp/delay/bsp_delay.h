#ifndef __BSP_DELAY_H
#define __BSP_DELAY_H
/***************************************************************
Copyright © zuozhongkai Co., Ltd. 1998-2019. All rights reserved.
文件名	: 	 bsp_delay.h
作者	   : 左忠凯
版本	   : V1.0
描述	   : 延时头文件。
其他	   : 无
论坛 	   : www.wtmembed.com
日志	   : 初版V1.0 2019/1/4 左忠凯创建
***************************************************************/
#include "imx6ul.h"

#define GPT1_INTERRPUT_DISABLE 0
/* 函数声明 */
void delay(volatile unsigned int n);
void delay_init(void);
void gpt1_irqhandler(uint32_t gicciar , void *param);
void delay_us(uint32_t usdelay);
void delay_ms(uint32_t msdelay);

#endif

