/***************************************************************
Copyright © zuozhongkai Co., Ltd. 1998-2019. All rights reserved.
文件名	: 	 bsp_delay.c
作者	   : 左忠凯
版本	   : V1.0
描述	   : 延时文件。
其他	   : 无
论坛 	   : www.wtmembed.com
日志	   : 初版V1.0 2019/1/4 左忠凯创建
***************************************************************/
#include "bsp_delay.h"
#include "bsp_int.h"
#include "bsp_led.h"

/*
 * @description	: 短时间延时函数
 * @param - n	: 要延时循环次数(空操作循环次数，模式延时)
 * @return 		: 无
 */
void delay_short(volatile unsigned int n)
{
	while(n--){}
}

/*
 * @description	: 延时函数,在396Mhz的主频下
 * 			  	  延时时间大约为1ms
 * @param - n	: 要延时的ms数
 * @return 		: 无
 */
void delay(volatile unsigned int n)
{
	while(n--)
	{
		delay_short(0x7ff);
	}
}

/*
 * @description	: 高精度延时函数初始化
 * 			  	  延时时间大约为1ms
 * @param - n	: 要延时的ms数
 * @return 		: 无
 */
void delay_init(void){
	/*GPT寄存器初始化*/
	volatile uint32_t temp = 0;
	GPT1->CR |= ((1 << 15) | (0 << 0)); //软复位标志位置一且关闭定时器
	while((GPT1->CR >> 15) & 0x01){};//等待软复位结束
	temp = ((1 << 1) | (1 << 6));//关闭定时器时清零计数器 选择外设时钟PERCLK_CLK_ROOT为频率
	//分频设置
	GPT1->PR = 65;//66分频 1Mhz计数频率
	//设置输出比较通道1
	GPT1->OCR[0] = 0xffffffff;//
	//设置为restart模式
	temp |= (0 << 9);
	//做延时作用不开启中断
	#if GPT1_INTERRPUT_DISABLE
	//打开通道1定时器中断
	GPT1->IR |= (1 << 0);
	GIC_EnableIRQ(GPT1_IRQn);//打开IRQ中断
	system_register_irqhandler(GPT1_IRQn, gpt1_irqhandler , NULL);
	#endif
	//开定时器
	temp |= 1 << 0;
	GPT1->CR |= temp;//写入
}

/*
 * @description	: GPT1z中断服务函数
 * 			  	  延时时间大约为1ms
 * @param - n	: 要延时的ms数
 * @return 		: 无
 */
void gpt1_irqhandler(uint32_t gicciar , void *param){
	static uint32_t status = 1;
	if(GPT1->SR & (1 << 0)){//输出比较1触发的中断
		status ^= 1;
		led_switch(LED0 , status , 0); 
	}
	GPT1->SR |= (1 << 0);//清中断标志位
}

/*
 * @description	: 延时us
 * 			  	  延时时间大约为1ms
 * @param - n	: 要延时的ms数
 * @return 		: 无
 */
void delay_us(uint32_t usdelay)
{
	uint64_t oldcnt , newcnt;
	uint64_t temp = 0;
	oldcnt = GPT1->CNT;
	while(1){
		newcnt = GPT1->CNT;
		if(newcnt > oldcnt){
			temp += newcnt - oldcnt;
			oldcnt = newcnt;
		}
		else if(newcnt < oldcnt){
			temp += (0xffffffff - oldcnt) + newcnt;
			oldcnt = newcnt;
		}
		if(temp >= usdelay){
        	break;
        }
	}
}

/*
 * @description	: 延时ms
 * 			  	  延时时间大约为1ms
 * @param - n	: 要延时的ms数
 * @return 		: 无
 */
void delay_ms(uint32_t msdelay)
{
    int i;
	for(i = 0;  i < msdelay; i++){
		delay_us(1000);
	}
}