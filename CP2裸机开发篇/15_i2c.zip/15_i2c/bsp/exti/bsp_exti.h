#ifndef __BSP_EXTI_H
#define __BSP_EXTI_H

#include "imx6ul.h"
void gpio1_io18_irqhandler(unsigned int gicciar , void *param);
void exti_init(void *base, int pin);
#endif // !__EXTI_H__
