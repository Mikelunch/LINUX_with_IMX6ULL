#ifndef __BSP_I2C_H__
#define __BSP_I2C_H__
#include "imx6ul.h"

/*i2c状态相关信息*/
#define I2C_BUSY  (1)
#define I2C_OK    (0)
#define I2C_IDLE  (2)   //空闲
#define I2C_NAK   (3) //从机不要回答
#define I2C_ARBITRLOST (4) //仲裁丢失
#define I2C_TIMEOUT (5) //超时
#define I2C_ADDRAK  (6) //地址应答信号

/*i2c传输方向*/
enum i2c_transfer{
    KI2c_Write , //主机写数据
    KI2c_Read 
};
void init_i2c(I2C_Type *base);
uint8_t i2c_master_start(I2C_Type *base , 
                        uint8_t address , enum i2c_transfer direction);
uint8_t i2c_master_stop(I2C_Type *base);
uint8_t i2c_master_restart(I2C_Type *base , 
                        uint8_t address , enum i2c_transfer direction);
uint8_t i2c_check_and_clear_error(I2C_Type *base , uint16_t state);


#endif // !__BSP_I2C_H__
