#include "bsp_i2c.h"

/*I2C接口初始(主机)*/
void init_i2c(I2C_Type *base){
    /*
     * I2CR寄存器设置
     * bit[7]:     0  0/1 关闭/使能I2C功能
     * bit[5] :  主从模式选择
     * bit[4] :  发送接受模式
     * bit[3] :  接受应答信号
     * bit[2] :  产生restart信号
	 */
    base->I2CR &= ~(1 << 7);//关闭i2c
    /*
     * I2C_IFDR寄存器设置
     * bit[0:7]: 15  640分频  I2C时钟分频 具体值见手册p1260页
	 */
    base->IFDR = 0x15; //66Mhz / 640 = 103.125kHz 标准模式下最大100kb/s 
    base->I2CR |= (1 << 7);//使能i2c
    
}

/*start信号产生*/
uint8_t i2c_master_start(I2C_Type *base , 
                        uint8_t address , enum i2c_transfer direction){
    //1判断是否总线忙
    if(base->I2CR & (1 << 5)){ //i2c忙
        return 1;//异常
    }
    //2设置为主机 并发送数据
    base->I2CR |= (1 << 5) | (1 << 4);//设置为主机 发送模式
    //3 写入从机地址 自动产生start信号
    /*
     * I2Cx_I2DR寄存器设置
     * bit[0 ： 7]: 从机地址
	 */
    base->I2DR = (address << 1) | 
    (direction == KI2c_Read ? 1 : 0);/*更具i2c协议 高7位是地址 第0位是主机读或者写信号
                                */
    return 0; //正常
}

/*stop信号产生*/
uint8_t i2c_master_stop(I2C_Type *base){
    uint16_t timeout = 0xffff;
    //1关闭i2c的接受相关使能位 设位从模式 、接受模式 、开启结束应答信号
    base->I2CR &= ~((1 << 5) | (1 << 4) | (1 << 3)); //是否只需要清bit3？
    //2等待i2c忙结束
    while(base->I2CR & (1 << 5)){
        timeout--;
        if(timeout == 0){
            return I2C_TIMEOUT;//异常
        }
    }
    return I2C_OK;
}

/*restart信号 -读时序用到*/
uint8_t i2c_master_restart(I2C_Type *base , 
                        uint8_t address , enum i2c_transfer direction){
    
    /*i2c是否忙或者工作在从机模式下 因为restart信号工作在
    读时序中间，检测下是否有其他器件将imx6u设位从即模式*/
    if(base->I2SR & (1 << 5) && base->I2CR & (1 << 5) == 0)
        return 1;//异常
    //设置成发送模式并产生restart信号
    base->I2CR |= (1 << 4) | (1 << 2);//发送模式 产生restart信号
    //发送要访问的地址并发送读信号
    base->I2DR = (address << 1) | 
    (direction == KI2c_Read ? 1 : 0);/*更具i2c协议 高7位是地址 第0位是主机读或者写信号
                                */
    return 0; //正常
}

/*错误检查函数*/
uint8_t i2c_check_and_clear_error(I2C_Type *base , uint16_t state){
    //1是否为总裁丢失错误
    if(state & (1 << 4)){
        base->I2SR &= ~(1 << 4);//总裁丢失错误
        base->I2CR &= ~(1 << 7);//重启一下I2C
        base->I2CR |= (1 << 7);
        return I2C_ARBITRLOST;//总裁丢失异常
    }
    else if(state & (1 << 0)){ //无应答错误
        return I2C_NAK;
    }
}