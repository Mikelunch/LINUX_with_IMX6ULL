#ifndef __BSP_AP3216C_H__
#define __BSP_AP3216C_H__
#include "bsp_ap3216c.h"


void AP3216C_Init(void);


#endif // !BSP_AP3216C_H__