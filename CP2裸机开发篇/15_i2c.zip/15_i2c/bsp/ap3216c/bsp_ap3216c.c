#include "bsp_ap3216c.h"
#include "bsp_i2c.h"
#include "bsp_gpio.h"

/*初始化AP3216C*/
void AP3216C_Init(void){
    //1 io初始化
    IOMUXC_SetPinMux(IOMUXC_UART4_TX_DATA_I2C1_SCL,1); //管脚复用 0是否官用
    IOMUXC_SetPinMux(IOMUXC_UART4_RX_DATA_I2C1_SDA,1);
    IOMUXC_SetPinConfig(IOMUXC_UART4_TX_DATA_I2C1_SCL , 0x70b0);//默认上拉 
    IOMUXC_SetPinConfig(IOMUXC_UART4_RX_DATA_I2C1_SDA , 0x70b0);
    //2 I2C接口初始化
}
