#include "bsp_int.h"

/*中断嵌套*/
static uint32_t irqNesting; //当前嵌套了几个中断
/*中断处理函数表*/
static system_irq_handle_t iqrTable[NUMBER_OF_INT_VECTORS];

/*初始化中断处理函数表*/
void system_iqrTable_init(void) {
    int i;
    irqNesting = 0;//清零嵌套计数器
    for (i = 0; i < NUMBER_OF_INT_VECTORS; i++) {
        iqrTable[i].irqhandler = default_iqrhandler;
        iqrTable[i].param = NULL;
    }
}
/*生成默认的中断处理函数入口地址*/
void default_iqrhandler(unsigned int gicciar , void *param) {
    while (1) {
    }
}

/*注册中断处理函数*/
/*
参数 IRQn_Type irqn:中断ID号
    system_irq_handle_t handler：需要注册的具体服务函数
    void * parm：需要注册的具体服务函数的参数
*/
void system_register_irqhandler(IRQn_Type irqn, system_irq_handler_t handler , void * parm) {
    iqrTable[irqn].irqhandler = handler;
    iqrTable[irqn].param = parm;
}

/*中断初始化*/
void int_init(void) {
    //c语言版本的中断初始化 效果和start.s中复位中断效果一样
    GIC_Init(); //GIC中断控制器初始化
    __set_VBAR(0x87800000); //设置中断向量表偏移
}

/*具体中断处理函数IRQ_Handler会调用次函数*/
void SystemIrqHandler(unsigned int gicciar){
    unsigned int irqnum = (gicciar & 0x3ff);//取出中断号
    //1.检查中断ID是否正常
    if(irqnum >= NUMBER_OF_INT_VECTORS){ //异常
        return;
    }
    irqNesting++;//中断嵌套计数器加1
    //2.根据ID号找到中断向量表中的对应的入口地址 参数会返回给r2寄存器，见start.s
    iqrTable[irqnum].irqhandler(irqnum , iqrTable[irqnum].param);
    irqNesting--;//当前中断处理完成
}

