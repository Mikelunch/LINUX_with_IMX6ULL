#include "bsp_exti.h"
#include "bsp_gpio.h"
#include "bsp_int.h"
#include "bsp_led.h"

/*
  * @description	 : GPIO外部中断初始化
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void exti_init(void *base, int pin){
    //1.初始化GPIO设置
    gpio_pin_config_t gpio_config;
    gpio_config.direction = kGPIO_DigitalInput; 
    gpio_config.gpio_interrput_mode = FALLING_EDGE;
    gpio_init(base , pin , &gpio_config);
    //2 中断服务函数注册
    system_register_irqhandler(GPIO1_Combined_16_31_IRQn ,gpio1_io18_irqhandler ,NULL);
    //3.使能中断
    GIC_EnableIRQ(GPIO1_Combined_16_31_IRQn);//开启外部中断
    gpio_interrput_enable(base , pin , 1); //开启GPIO中断
}

/*
  * @description	 : GPIO外部中断服务函数
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void gpio1_io18_irqhandler(unsigned int gicciar , void *param){
    static uint8_t state = 0;
    if(gpio_pinread(GPIO1 , 18) == 0){
        state ^= 1;
        led_switch(LED0 , state , 10); 
    }
    /*清除中断标志位*/
    gpio_clearflag(GPIO1 , 18);
}