#include "bsp_uart.h"

/*
  * @description	 : 初始化UART1
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_init(UART_Type *base , uint32_t bort_rate){
    volatile uint32_t temp = 0;
    /*设置GPIO接口*/
    IOMUXC_SetPinMux(IOMUXC_UART1_RX_DATA_UART1_RX ,0); /*注意不要搞混成
                                                    IOMUXC_UART1_TX_DATA_UART1_RX                */
    /* 配置IOMUXC_UART1_RX_DATA_UART1_RX的IO属性	
	 *bit 16:0 HYS关闭
	 *bit [15:14]: 00 默认下拉
	 *bit [13]: 0 kepper功能
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 110 R0/6驱动能力
	 *bit [0]: 0 低转换率
	 */
    IOMUXC_SetPinConfig(IOMUXC_UART1_RX_DATA_UART1_RX,0X10B0);
    IOMUXC_SetPinMux(IOMUXC_UART1_TX_DATA_UART1_TX ,0); //设置IO复用位UART1_TX
    /* 配置IOMUXC_UART1_TX_DATA_UART1_TX的IO属性	
	 *bit 16:0 HYS关闭
	 *bit [15:14]: 00 默认下拉
	 *bit [13]: 0 kepper功能
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 110 R0/6驱动能力
	 *bit [0]: 0 低转换率
	 */
    IOMUXC_SetPinConfig(IOMUXC_UART1_TX_DATA_UART1_TX,0X10B0);
    
    uart_disable(base);//在初始化前关闭串口
    uart_softrestart(base);//复位UART1

    /*配置UART相关参数*/
    temp = 0;
    base->UCR1 = temp; //清零 关闭包括自动波特率检测在内的功能

    temp = 0;
    base->UCR2 = temp; //清零
    temp |= (1 << 1) | (1 << 2); //使能发送和接受功能
    temp |= (1 << 5) | (0 << 6); //8位数据位、一位停止位
    temp |= (1 << 14); //关闭RTS管脚
    base->UCR2 = temp;

    temp = 0;
    base->UCR3 = temp;
    temp |= (1 << 2);//说明文档规定该位必须位1
    base->UCR3 = temp;
#if 0
    /*设置波特率  （参考频率）
    波特率 =     ----------
                （16 *  UBMR + 1）
                        --------
                        UBIR + 1）    
    */
    base->UFCR &= ~(7 << 7);//1分频 参考频率= 80MHZ
    base->UFCR |= (5 << 7);
    temp = 0;
    base->UBIR = temp;
    base->UBMR = temp;
    temp |= (3124 << 0);
    base->UBMR = temp;
    temp = 0;
    temp |= (71 << 0);
    base->UBIR = temp;
#endif
  uart_setbaudrate(UART1, bort_rate, 80000000);   
    /*使能UART1*/
  uart_ensable(base);
}

/*
  * @description	 : 关闭UART1
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_disable(UART_Type *base){
    base->UCR1 &= ~(1 << 0); //第0位清零即可
}

/*
  * @description	 : 开启UART1
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_ensable(UART_Type *base){
    base->UCR1 |= (1 << 0); //第0位置1即可
}

/*
  * @description	 : 软复位UART1
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_softrestart(UART_Type *base){
    base->UCR2 &= ~(1 << 0); //开启软复位
    while((base->UCR2 & 0x1) == 0){};//等待复位完成
}

/*
  * @description	 :   接受一个字符数据
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/

uint8_t uart_recivevChar(UART_Type *base){
    while(((base->USR2 >> 0) & 0x01 ) == 0){} //等待缓冲结束
    return (uint8_t)(base->URXD);
}

/*
  * @description	 :   发送一个字符数据
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_sendChar(UART_Type *base,uint8_t data){
    while(((base->USR2 >> 3) & 0x01) == 0){} //等待缓冲结束
    base->UTXD = data;
}

/*
  * @description	 :   发送一串字符数据
  * @param - bort_rate	 : 波特率
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void uart_sendStr(UART_Type *base, const char *str){
    while(*str != '\0'){
        uart_sendChar(base,*str);
        str++;
    }
}

/*
 * @description 		: 波特率计算公式，
 *    			  	  	  可以用此函数计算出指定串口对应的UFCR，
 * 				          UBIR和UBMR这三个寄存器的值
 * @param - base		: 要计算的串口。
 * @param - baudrate	: 要使用的波特率。
 * @param - srcclock_hz	:串口时钟源频率，单位Hz
 * @return		: 无
 */
void uart_setbaudrate(UART_Type *base, unsigned int baudrate, unsigned int srcclock_hz)
{
    uint32_t numerator = 0u;		//分子
    uint32_t denominator = 0U;		//分母
    uint32_t divisor = 0U;
    uint32_t refFreqDiv = 0U;
    uint32_t divider = 1U;
    uint64_t baudDiff = 0U;
    uint64_t tempNumerator = 0U;
    uint32_t tempDenominator = 0u;

    /* get the approximately maximum divisor */
    numerator = srcclock_hz;
    denominator = baudrate << 4;
    divisor = 1;

    while (denominator != 0)
    {
        divisor = denominator;
        denominator = numerator % denominator;
        numerator = divisor;
    }

    numerator = srcclock_hz / divisor;
    denominator = (baudrate << 4) / divisor;

    /* numerator ranges from 1 ~ 7 * 64k */
    /* denominator ranges from 1 ~ 64k */
    if ((numerator > (UART_UBIR_INC_MASK * 7)) || (denominator > UART_UBIR_INC_MASK))
    {
        uint32_t m = (numerator - 1) / (UART_UBIR_INC_MASK * 7) + 1;
        uint32_t n = (denominator - 1) / UART_UBIR_INC_MASK + 1;
        uint32_t max = m > n ? m : n;
        numerator /= max;
        denominator /= max;
        if (0 == numerator)
        {
            numerator = 1;
        }
        if (0 == denominator)
        {
            denominator = 1;
        }
    }
    divider = (numerator - 1) / UART_UBIR_INC_MASK + 1;

    switch (divider)
    {
        case 1:
            refFreqDiv = 0x05;
            break;
        case 2:
            refFreqDiv = 0x04;
            break;
        case 3:
            refFreqDiv = 0x03;
            break;
        case 4:
            refFreqDiv = 0x02;
            break;
        case 5:
            refFreqDiv = 0x01;
            break;
        case 6:
            refFreqDiv = 0x00;
            break;
        case 7:
            refFreqDiv = 0x06;
            break;
        default:
            refFreqDiv = 0x05;
            break;
    }
    /* Compare the difference between baudRate_Bps and calculated baud rate.
     * Baud Rate = Ref Freq / (16 * (UBMR + 1)/(UBIR+1)).
     * baudDiff = (srcClock_Hz/divider)/( 16 * ((numerator / divider)/ denominator).
     */
    tempNumerator = srcclock_hz;
    tempDenominator = (numerator << 4);
    divisor = 1;
    /* get the approximately maximum divisor */
    while (tempDenominator != 0)
    {
        divisor = tempDenominator;
        tempDenominator = tempNumerator % tempDenominator;
        tempNumerator = divisor;
    }
    tempNumerator = srcclock_hz / divisor;
    tempDenominator = (numerator << 4) / divisor;
    baudDiff = (tempNumerator * denominator) / tempDenominator;
    baudDiff = (baudDiff >= baudrate) ? (baudDiff - baudrate) : (baudrate - baudDiff);

    if (baudDiff < (baudrate / 100) * 3)
    {
        base->UFCR &= ~UART_UFCR_RFDIV_MASK;
        base->UFCR |= UART_UFCR_RFDIV(refFreqDiv);
        base->UBIR = UART_UBIR_INC(denominator - 1); //要先写UBIR寄存器，然后在写UBMR寄存器，3592页 
        base->UBMR = UART_UBMR_MOD(numerator / divider - 1);
    }
}

/*定义raise函数 防止报错*/
void raise(int sig_nr)
{
	
}