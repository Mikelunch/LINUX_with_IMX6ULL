#include "bsp_clk.h"
#include "bsp_delay.h"
#include "bsp_led.h"
#include "bsp_beep.h"
#include "bsp_key.h"
#include "bsp_int.h"
#include "bsp_exti.h"
#include "bsp_epit.h"
#include "bsp_gpio.h"
#include "bsp_uart.h"

/*
 * @description	: main函数
 * @param 		: 无
 * @return 		: 无
 */
int main(void)
{
	int_init();
	IMX_ARM_clk_init(ARM_CLK_528);			//初始化主频
	clk_enable();		/* 使能所有的时钟 			*/
	uart_init(UART1 , 115200);         /* 使能串口 			*/ 
	delay_init();        /* 使能GPT定时器的延时函数            */
	led_init();			/* 初始化led 			*/
	beep_init();		/* 初始化beep	 		*/
	key_init();			/* 初始化key 			*/
 	exti_init(GPIO1 , 18); /* 初始化外部中断			*/
	epit_init(66,1e6);  /* 初始化EPIT定时器中断	 66分频 计数10^6 但并没有开始工作*/
	volatile char s;
	while(1)			
	{	
		static uint8_t state = 0;
    	state ^= 1;
        led_switch(LED0 , state , 500);
		uart_sendStr(UART1 , "请输入一个字符：");
		s = uart_recivevChar(UART1);
		uart_sendStr(UART1 , "输入的字符是：");
		uart_sendChar(UART1 , s);
		uart_sendStr(UART1 , "\r\n");
	}
	return 0;
}
