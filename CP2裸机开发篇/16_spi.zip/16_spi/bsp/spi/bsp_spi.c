#include "bsp_spi.h"

/*SPI初始化*/

void spi_init(ECSPI_Type *base){
    printf("开始SPI初始化\r\n");
    /*CONREG寄存器配置
    * bit[0] 1 : SPI使能位   1:开启SPI使能 
    * bit[3] 1 : 开启模式选择 1：立即开始SPI突发访问模式
    * bit[4 : 7] 0001 : 通道模式选择 0001：通道0设置为主模式
    * bit[18:19] 00   : 通道选择    00：通道0被片选
    * bit[20:31] 0x1  : 突发访问模式数据长度 0x7: 一字节长度
    * bit[8 : 11] 0 :  再分频 将预分频的时钟元再分频 0x2 : 预分频 / 2^2
    * bit[12 : 15] 9 : 预分频 将ECSPI的时钟元进行分频
    */
    base->CONREG = 0; //清零配置
    base->CONREG |= (1 << 0) | (1 << 3) | (1 << 4) | (0 << 18) | (7 << 20);

    /*CONFIGREG寄存器配置
    * bit[0 : 3]   0 : CPHA极性相位 0: 串行时钟的第一个条边沿开始采集数据
    * bit[4 : 7]   0 : CPOL极性相位 0: 串行时钟空闲为低电平
    * bit[16 : 19] 0 : 数据线空闲时电平  0: 空闲为低电平
    * bit[20 : 23] 0 : 时钟线空闲时电平  0： 空闲时为低电平
    */
    base->CONFIGREG = 0;

    /*PERIODREG寄存器配置
    * bit[0 : 14] : 0x2000 :等待周期控制 0x2000:发送数据后插入0x2000个CLK
    * bit[15] : 0 :CLK时钟来源 0：SCLK时钟源
    */
    base->PERIODREG = 0x2000;

    /*SPI时钟原设置 ICM20608最高8Mhz 历程配置为6Mhz*/
    //1 设置ECSPI时钟来源为PLL3_60Mhz
    CCM->CSCDR2 &= ~(1 << 18); //pll3_60Mhz
    CCM->CSCDR2 &= ~(0x3f << 19); //一分频
    //2 配置CONFIGREG来分频pll3_60Mhz到8hz
    base->CONREG &= ~((0xf << 8) | (0xf << 12));
    base->CONREG |= (0x9 << 12) | (0 << 8); // 60 / 10 = 6Mhz
    printf("SPI初始化完毕\r\n");
}

/*SPI读/写数据接口*/
uint8_t spich0_readwrite_byte(ECSPI_Type *base , uint8_t txdata){
    uint32_t spirxdata = 0;
    uint32_t spitxdata = txdata;//rxdata寄存器是32位
    uint32_t timeout = 0xffffffff;
    /*选择通道0*/
    base->CONREG &= ~(3 << 18);
    /*数据发送*/
    while((base->STATREG & 0x1) == 0){ //等待上一个数据发送
        timeout--;
        if(timeout == 0){
            printf("SPI发送数据超时!\r\n");
            timeout = 0xffffffff;
        }     
    }
    //printf("准备发送数据 , 发送数据为 data = %#x\r\n" ,spitxdata);
    base->TXDATA = spitxdata;//发送数据
    //printf("发送数据成功! data = %#x\r\n" , spitxdata);

    /*数据接收*/
    timeout = 0xffffffff; 
    while((base->STATREG & (1 << 3)) == 0){ //等待上一个数据发送
        timeout--;
        if(timeout == 0){
            printf("SPI接收数据超时!\r\n");
            timeout = 0xffffffff; 
        }
    }
    spirxdata = base->RXDATA;//接受数据
    //printf("接收数据成功! data = %d\r\n" , spirxdata);
    return (uint8_t)spirxdata;
}

