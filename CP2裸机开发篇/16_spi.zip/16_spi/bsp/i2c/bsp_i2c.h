#ifndef __BSP_I2C_H__
#define __BSP_I2C_H__
#include "imx6ul.h"

/*i2c状态相关信息*/
#define I2C_BUSY  (1)
#define I2C_OK    (0)
#define I2C_IDLE  (2)   //空闲
#define I2C_NAK   (3) //从机不要回答
#define I2C_ARBITRLOST (4) //仲裁丢失
#define I2C_TIMEOUT (5) //超时
#define I2C_ADDRAK  (6) //地址未应答信号

/*i2c传输方向*/
enum i2c_direction{
    KI2c_Write , //主机写数据
    KI2c_Read 
};

/*
 * 主机传输结构体
 */
struct i2c_transfer
{
    unsigned char slaveAddress;      	/* 7位从机地址 			*/
    enum i2c_direction direction; 		/* 传输方向 			*/
    unsigned int subaddress;       		/* 寄存器地址			*/
    unsigned char subaddressSize;    	/* 寄存器地址长度 			*/
    unsigned char *volatile data;    	/* 数据缓冲区 			*/
    volatile unsigned int dataSize;  	/* 数据缓冲区长度 			*/
};

void init_i2c(I2C_Type *base);
uint8_t i2c_master_start(I2C_Type *base , 
                        uint8_t address , enum i2c_direction direction);
uint8_t i2c_master_stop(I2C_Type *base);
uint8_t i2c_master_restart(I2C_Type *base , 
                        uint8_t address , enum i2c_direction direction);
uint8_t i2c_check_and_clear_error(I2C_Type *base , uint16_t state);

void i2c_master_write(I2C_Type *base , const uint8_t *buffer ,
             uint32_t buffsize);

void i2c_master_read(I2C_Type *base, uint8_t *buf, uint32_t bufsize);
unsigned char i2c_master_transfer(I2C_Type *base, struct i2c_transfer *xfer);


#endif // !__BSP_I2C_H__
