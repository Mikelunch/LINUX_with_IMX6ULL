#include "bsp_i2c.h"
#include "stdio.h"

/*I2C接口初始(主机)*/
void init_i2c(I2C_Type *base){
    /*
     * I2CR寄存器设置
     * bit[7]:     0  0/1 关闭/使能I2C功能
     * bit[5] :  主从模式选择
     * bit[4] :  发送接受模式
     * bit[3] :  接受应答信号
     * bit[2] :  产生restart信号
	 */
    base->I2CR &= ~(1 << 7);//关闭i2c
    /*
     * I2C_IFDR寄存器设置
     * bit[0:7]: 15  640分频  I2C时钟分频 具体值见手册p1260页
	 */
    base->IFDR = 0x15; //66Mhz / 640 = 103.125kHz 标准模式下最大100kb/s 
    base->I2CR |= (1 << 7);//使能i2c
    
}

/*start信号产生*/
uint8_t i2c_master_start(I2C_Type *base , 
                        uint8_t address , enum i2c_direction direction){
    //1判断是否总线忙
    if(base->I2CR & (1 << 5)){ //i2c忙
        return 1;//异常
    }
    //2设置为主机 并发送数据
    base->I2CR |= (1 << 5) | (1 << 4);//设置为主机 发送模式
    //3 写入从机地址 自动产生start信号
    /*
     * I2Cx_I2DR寄存器设置
     * bit[0 ： 7]: 从机地址
	 */
    base->I2DR = (address << 1) | 
    (direction == KI2c_Read ? 1 : 0);/*更具i2c协议 高7位是地址 第0位是主机读或者写信号
                                */
    return 0; //正常
}

/*stop信号产生*/
uint8_t i2c_master_stop(I2C_Type *base){
    uint16_t timeout = 0xffff;
    //1关闭i2c的接受相关使能位 设位从模式 、接受模式 、开启结束应答信号
    base->I2CR &= ~((1 << 5) | (1 << 4) | (1 << 3)); //是否只需要清bit3？
    //2等待i2c忙结束
    while(base->I2SR & (1 << 5)){
        timeout--;
        if(timeout == 0){
            printf("\r\n timeout!\r\n");
            return I2C_TIMEOUT;//异常
        }
    }
    return I2C_OK;
}

/*restart信号 -读时序用到*/
uint8_t i2c_master_restart(I2C_Type *base , 
                        uint8_t address , enum i2c_direction direction){
    
    /*i2c是否忙或者工作在从机模式下 因为restart信号工作在
    读时序中间，检测下是否有其他器件将imx6u设位从即模式*/
    if((base->I2SR & (1 << 5) && base->I2CR & (1 << 5)) == 0)
        return 1;//异常
    //设置成发送模式并产生restart信号
    base->I2CR |= (1 << 4) | (1 << 2);//发送模式 产生restart信号
    //发送要访问的地址并发送读信号
    base->I2DR = (address << 1) | 
    (direction == KI2c_Read ? 1 : 0);/*更具i2c协议 高7位是地址 第0位是主机读或者写信号
                                */
    return 0; //正常
}

/*错误检查函数*/
uint8_t i2c_check_and_clear_error(I2C_Type *base , uint16_t state){
    //1是否为总裁丢失错误
    if(state & (1 << 4)){
        base->I2SR &= ~(1 << 4);//总裁丢失错误
        base->I2CR &= ~(1 << 7);//重启一下I2C
        base->I2CR |= (1 << 7);
        return I2C_ARBITRLOST;//总裁丢失异常
    }
    else if(state & (1 << 0)){ //无应答错误
        return I2C_NAK;
    }
    return I2C_OK;//正常
}

/*i2c发送数据
    *注意坑：等待数据传出完成不是用 I2SR的bit7而是用bit1中断来 沟槽的NXP

*/
void i2c_master_write(I2C_Type *base , const uint8_t *buffer ,
             uint32_t buffsize){
    //1等待上一个数据传输完成
    while((base->I2SR & (1 << 7)) == 0){}
    base->I2SR &= ~(1 << 1); //清除中断标志位 后续看可不可以删除？
    //2发送数据
    base->I2CR |= (1 << 4); //设置为发送模式
    while(buffsize--){
        base->I2DR = *buffer++;//发送数据
        //while(base->I2SR & (1 << 7) == 0){} //后续看能不能使用这个判断
        while(((base->I2SR) & (1 << 1)) == 0){} //SDK包这样判断的
        base->I2SR &= ~(1 << 1); //清除 以便下一次使用
        //每发送一个字节数据要求从机回应
        if(i2c_check_and_clear_error(base , base->I2SR))
            break;
    }
    base->I2SR &= ~(1 << 1);//清除状态 看能不能删除？
    //3发送停止信号
    i2c_master_stop(base); //

}
/*i2c读数据*/
void i2c_master_read(I2C_Type *base, uint8_t *buf, uint32_t bufsize){

    volatile uint8_t dummy = 0; //假读一次
    dummy++;
    //1等待总线传输完成
    while((base->I2SR & (1 << 7)) == 0){}
    base->I2SR &= ~(1 << 1); //清除中断标志位 后续看可不可以删除？
    //2接受数据
    base->I2CR &= ~((1 << 4) | (1 << 3)); //清除第3 和 第4位
    if(bufsize == 1){//只有一个数据 按照协议直接发送NAK信号
        base->I2CR |= (1 << 3); 
    }
    dummy = base->I2DR; //假读一次
    while(bufsize--){
        while((base->I2SR & (1 << 1)) == 0) {}//等待数据传输完成
        base->I2SR &= ~(1 << 1);
        if(bufsize == 0){ //数据发送完成
            i2c_master_stop(base);
        }
        if(bufsize == 1){ //根据协议 i2c在发送倒数第二个数据时
            base->I2CR |= (1 << 3); //发送NAK信号
        }
        *buf++ = base->I2DR; //从寄存器中取出数据
    }
}


/*
 * @description	: I2C数据传输，包括读和写
 * @param - base: 要使用的IIC
 * @param - xfer: 传输结构体
 * @return 		: 传输结果,0 成功，其他值 失败;
 */
unsigned char i2c_master_transfer(I2C_Type *base, struct i2c_transfer *xfer)
{
	unsigned char ret = 0;
	 enum i2c_direction direction = xfer->direction;	

	base->I2SR &= ~((1 << 1) | (1 << 4));			/* 清除标志位 */

	/* 等待传输完成 */
	while(!((base->I2SR >> 7) & 0X1)){}; 

	/* 如果是读的话，要先发送器件地址，所以要先将方向改为写 */
    if ((xfer->subaddressSize > 0) && (xfer->direction == KI2c_Read))
    {
        direction = KI2c_Write;
    }

	ret = i2c_master_start(base, xfer->slaveAddress, direction); /* 发送开始信号 */
    if(ret)
    {	
		return ret;
	}

	while(!(base->I2SR & (1 << 1))){};			/* 等待传输完成 */

    ret = i2c_check_and_clear_error(base, base->I2SR);	/* 检查是否出现传输错误 */
    if(ret)
    {
      	i2c_master_stop(base); 						/* 发送出错，发送停止信号 */
        return ret;
    }
	
    /* 发送寄存器地址 */
    if(xfer->subaddressSize)
    {
        do
        {
			base->I2SR &= ~(1 << 1);			/* 清除标志位 */
            xfer->subaddressSize--;				/* 地址长度减一 */
			
            //从高位数据开始发送 
            base->I2DR =  ((xfer->subaddress) >> (8 * xfer->subaddressSize)); //向I2DR寄存器写入子地址
  
			while(!(base->I2SR & (1 << 1)));  	/* 等待传输完成 */

            /* 检查是否有错误发生 */
            ret = i2c_check_and_clear_error(base, base->I2SR);
            if(ret)
            {
             	i2c_master_stop(base); 				/* 发送停止信号 */
             	return ret;
            }  
        } while ((xfer->subaddressSize > 0) && (ret == I2C_OK));

        if(xfer->direction == KI2c_Read) 		/* 读取数据 写数据则该步忽略*/
        {
            base->I2SR &= ~(1 << 1);			/* 清除中断挂起位 */
            i2c_master_restart(base, xfer->slaveAddress, KI2c_Read); /* 发送重复开始信号和从机地址 */
    		while(!(base->I2SR & (1 << 1))){};/* 等待传输完成 */

            /* 检查是否有错误发生 */
			ret = i2c_check_and_clear_error(base, base->I2SR);
            if(ret)
            {
             	ret = I2C_ADDRAK;
                i2c_master_stop(base); 		/* 发送停止信号 */
                return ret;  
            }
           	          
        }
    }	


    /* 发送数据 */
    if ((xfer->direction == KI2c_Write) && (xfer->dataSize > 0))
    {
    	i2c_master_write(base, xfer->data, xfer->dataSize);
	}

    /* 读取数据 */
    if ((xfer->direction == KI2c_Read) && (xfer->dataSize > 0))
    {
       	i2c_master_read(base, xfer->data, xfer->dataSize);
	}
	return 0;	
}
