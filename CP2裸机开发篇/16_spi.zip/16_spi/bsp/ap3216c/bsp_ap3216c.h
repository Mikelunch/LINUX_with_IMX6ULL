#ifndef __BSP_AP3216C_H__
#define __BSP_AP3216C_H__
#include "bsp_ap3216c.h"
#include "imx6ul.h"

/*寄存器地址*/
//系统地址寄存器地址
#define AP3216C_REGADDR   0X1E
#define AP3216C_SYSCONFIG 0x00
#define AP3216C_INTS      0x01
#define AP3216C_INTCLEAN      0X02
#define AP3216C_IRDATAL   0X0A
#define AP3216C_IRDATAH  0X0B
#define AP3216C_ALSDATAH 0X0D
#define AP3216C_ALSDATAL 0X0C
#define AP3216C_PSDATAH 0X0F
#define AP3216C_PSDATAL 0X0E

/*传感器数据结构体*/
struct ap3216c_data
{
    uint16_t ir_data; //红外线输出数据
    uint16_t als_data;//环境光传感器
    uint16_t ps_data; //距离检测传感器
};

void AP3216C_Init(void);
uint8_t AP3216C_ReadByte(uint8_t addr, uint8_t reg);
uint8_t AP3216C_WriteByte(uint8_t addr, uint8_t reg , uint8_t data);

void AP3216C_readSensorData(struct ap3216c_data *buffer);

#endif // !BSP_AP3216C_H__