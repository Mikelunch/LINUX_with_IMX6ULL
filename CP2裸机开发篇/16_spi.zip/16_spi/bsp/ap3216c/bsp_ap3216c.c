#include "bsp_ap3216c.h"
#include "bsp_i2c.h"
#include "bsp_gpio.h"
#include "bsp_delay.h"
#include "stdio.h"

/*初始化AP3216C*/
void AP3216C_Init(void){
    printf("开始AP3216C初始化\r\n");
    uint8_t val;
    //1 io初始化
    IOMUXC_SetPinMux(IOMUXC_UART4_TX_DATA_I2C1_SCL,1); //管脚复用 0是否官用
    IOMUXC_SetPinMux(IOMUXC_UART4_RX_DATA_I2C1_SDA,1);
    IOMUXC_SetPinConfig(IOMUXC_UART4_TX_DATA_I2C1_SCL , 0x70b0);//默认上拉 
    IOMUXC_SetPinConfig(IOMUXC_UART4_RX_DATA_I2C1_SDA , 0x70b0);
    printf("AP3216CIO初始化完毕\r\n");
    //2 I2C接口初始化
    init_i2c(I2C1);
    printf("硬件I2C初始化完毕\r\n");
    //3 AP3216C传感器配置
    AP3216C_WriteByte(AP3216C_REGADDR , AP3216C_SYSCONFIG , 0x04);//复位AP32
    printf("向AP3216C写入数据\r\n");
    delay_ms(50);
    AP3216C_WriteByte(AP3216C_REGADDR , AP3216C_SYSCONFIG , 0x03);//开启ALS + PS + IR模式
    printf("开启AP3216C所有传感器\r\n");
    val = AP3216C_ReadByte(AP3216C_REGADDR , AP3216C_SYSCONFIG);
    printf("\r\n AP3216C_SYSCONFIG = %#x\r\n" , val);
    printf("开始AP3216C完毕\r\n");
}

/*AP3216C读字节*/
uint8_t AP3216C_ReadByte(uint8_t addr, uint8_t reg){
    uint8_t data;
    struct i2c_transfer xfer;
    xfer.slaveAddress = addr;
    xfer.direction = KI2c_Read;
    xfer.subaddress = reg;
    xfer.subaddressSize = 1;
    xfer.data = &data;
    xfer.dataSize = 1;
    i2c_master_transfer(I2C1, &xfer);
    return data;
}

/*AP3216C写字节*/
uint8_t AP3216C_WriteByte(uint8_t addr, uint8_t reg , uint8_t data){
    struct i2c_transfer xfer;
    xfer.slaveAddress = addr;
    xfer.direction = KI2c_Write;
    xfer.subaddress = reg;
    xfer.subaddressSize = 1;
    xfer.data = &data;
    xfer.dataSize = 1;
    return i2c_master_transfer(I2C1, &xfer);
}

/*AP3216C数据读取*/
void AP3216C_readSensorData(struct ap3216c_data *buffer){
    uint8_t buf[6]; //暂存所有数据
    uint8_t i;
    for(i = 0; i < 6; i++){
        buf[i] = AP3216C_ReadByte(AP3216C_REGADDR , AP3216C_IRDATAL + i);
    }
    if((buf[0] & (1 << 7)) == 1){//判定ir ps数据是否有效
        buffer->ir_data = 0;//无效数据
        buffer->ps_data = 0;
    }
    else{//有效
        buffer->ir_data = (uint16_t)(buf[1] << 2) | (buf[0] & (0x3));
        buffer->als_data = (uint16_t)(buf[3] << 8) | (buf[2]);
        buffer->ps_data = (uint16_t)(buf[5] & 0x3f << 4) | (buf[4] & (0xf));
    }
}