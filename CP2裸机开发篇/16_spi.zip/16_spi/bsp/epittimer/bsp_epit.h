#ifndef __BSP_EPIT_H
#define __BSP_EPIT_H
#include "imx6ul.h"

void epit_init(uint32_t frac , uint32_t val);
void epit1_irqhandler(unsigned int gicciar , void *param);

#endif // !__BSP_EPIT_H
