#include "bsp_clk.h"
#include "bsp_delay.h"
#include "bsp_led.h"
#include "bsp_beep.h"
#include "bsp_key.h"
#include "bsp_int.h"
#include "bsp_exti.h"
#include "bsp_epit.h"
#include "bsp_gpio.h"
#include "bsp_uart.h"
#include "bsp_lcd.h"
#include "bsp_lcdapi.h"
#include "bsp_rtc.h"
#include "bsp_ap3216c.h"
#include "bsp_i2c.h"
#include "stdio.h"
#include "bsp_icm20608.h"
#include "bsp_spi.h"
#include "bsp_myfunction.h"

/*
 * @description	: 使能I.MX6U的硬件NEON和FPU 想要使用flaot类型必须打开
 * @param 		: 无
 * @return 		: 无
 * 详细参考资料<rence Manual ARMv7-A and ARMv7-R edition.pdf>
 * 同时，在C编译MakeFile中加入浮点运算编译
 */
 void imx6ul_hardfpu_enable(void)
{
	uint32_t cpacr;
	uint32_t fpexc;

	/* 使能NEON和FPU */
	cpacr = __get_CPACR();
	cpacr = (cpacr & ~(CPACR_ASEDIS_Msk | CPACR_D32DIS_Msk))
		   |  (3UL << CPACR_cp10_Pos) | (3UL << CPACR_cp11_Pos);
	__set_CPACR(cpacr);
	fpexc = __get_FPEXC();
	fpexc |= 0x40000000UL;	
	__set_FPEXC(fpexc);
}




/*
 * @description	: main函数
 * @param 		: 无
 * @return 		: 无
 */
int main(void)
{
	static uint8_t state = 1;
	imx6ul_hardfpu_enable(); /*使能浮点						*/
	int_init();
	IMX_ARM_clk_init(ARM_CLK_528);			//初始化主频
	clk_enable();		/* 使能所有的时钟 			*/
	delay_init();        /* 使能GPT定时器的延时函数            */
	uart_init(UART1 , 115200);         /* 使能串口 			*/ 
	printf("\r\n\r\n -------------开始初始化-------------\r\n\r\n");
	led_init();			/* 初始化led 			*/
	beep_init();		/* 初始化beep	 		*/
	key_init();			/* 初始化key 			*/
 	exti_init(GPIO1 , 18); /* 初始化外部中断			*/
	epit_init(66,1e6);  /* 初始化EPIT定时器中断	 66分频 计数10^6 但并没有开始工作*/
	lcd_init();			/*屏幕初始化						*/
	my_lcd_config.forecolor = LCD_RED;
	my_lcd_config.backcolor = LCD_WHITE;
	AP3216C_Init();   /*传感器AP3216C初始化						*/
	init_icm20608();  /*传感器ICM20608初始化						*/

	struct numFomat flaot2Int;

	printf("\r\n\r\n------进入主循环------\r\n");
	while(1)			
	{
		icm20608_getdata();
		printf("gyro_x  =  %d\r\n" , icm20608_dev.gyro_x_act);
		printf("处理数据后结果\r\n");
		handle_num(icm20608_dev.gyro_x_act , &flaot2Int);
		if(flaot2Int.flag)
			printf("gyro_x  =  -%d.%c%c\r\n",flaot2Int.integer_part , flaot2Int.float_part[2] ,
											flaot2Int.float_part[1]);
		else 
			printf("gyro_x  =  %d.%c%c\r\n",flaot2Int.integer_part , flaot2Int.float_part[2] ,
											flaot2Int.float_part[1]);
		// printf("gyro_y  =  %d\r\n" , icm20608_dev.gyro_y_act);
		// printf("gyro_z  =  %d\r\n" , icm20608_dev.gyro_z_act);
		// printf("accel_x =  %d\r\n" , icm20608_dev.accel_x_act);
		// printf("accel_y =  %d\r\n" , icm20608_dev.accel_y_act);
		// printf("accel_z =  %d\r\n" , icm20608_dev.accel_z_act);
		// printf("temp    =  %d\r\n" , icm20608_dev.temp_act);
		printf("\r\n");

		state ^= 1;
		led_switch(LED0 , state , 0);
		delay_ms(500);
	}
	return 0;
}
