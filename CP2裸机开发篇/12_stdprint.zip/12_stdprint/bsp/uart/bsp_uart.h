#ifndef __BSP_UART_H__
#define __BSP_UART_H__

#include "imx6ul.h"
void uart_disable(UART_Type *base);
void uart_ensable(UART_Type *base);
void uart_softrestart(UART_Type *base);
void uart_init(UART_Type *base , uint32_t bort_rate);
void uart_sendStr(UART_Type *base,const char *str);
void uart_sendChar(UART_Type *base,uint8_t data);
uint8_t uart_recivevChar(UART_Type *base);
void uart_setbaudrate(UART_Type *base, unsigned int baudrate, unsigned int srcclock_hz);





#endif