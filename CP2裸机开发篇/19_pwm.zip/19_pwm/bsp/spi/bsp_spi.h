#ifndef __BSP_SPI_H__
#define __BSP_SPI_H__
#include "imx6ul.h"
#include "stdio.h"

void spi_init(ECSPI_Type *base);
uint8_t spich0_readwrite_byte(ECSPI_Type *base , uint8_t txdata);

#endif // !__BSP_SPI_H__

