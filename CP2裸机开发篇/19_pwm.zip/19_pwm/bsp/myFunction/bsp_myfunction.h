#ifndef __BSP_MYFUNCTION_H__
#define __BSP_MYFUNCTION_H__

#include "stdio.h"
#include "imx6ul.h"

/*整数转浮点数处理
 * 默认2位小数 默认处理int16_t数据
*/
struct numFomat
{
    unsigned int  flag;
    unsigned int  integer_part;
    char  float_part[3];
};
unsigned int numBuf[32];

void handle_num(int num , struct numFomat *handle);

#endif // !__BSP_MYFUNCTION_H__
