#include "bsp_backlight.h"


struct backlight_dev_str back_light_dev;
/*初始化背光 PWM初始化*/
void backlight_init(void){
    unsigned int i = 0;
    //1 IO初始化
    printf("开始LCD背光初始化\r\n");
    //1 io初始化
    /* 配置PWM相关IO属性	                   
	 *bit 16:0 HYS关闭
	 *bit [15:14]: 10 上拉                    
	 *bit [13]: 1 pull功能                                        
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 010 R0/4驱动能力              
	 *bit [0]: 0 低转换率                     
	 */
    IOMUXC_SetPinMux(IOMUXC_GPIO1_IO08_PWM1_OUT,0); //管脚复用 0 强制复用
    IOMUXC_SetPinConfig(IOMUXC_GPIO1_IO08_PWM1_OUT , 0xb090);//默认上拉 
    printf("pwm1IO初始化完毕\r\n");
    //2 PWM初始化
    /* 配置PWMCR	                   
	 *bit [17:16]:01  IPG——CLK时钟输入
	 *bit [15:14]: 10 上拉                    
	 *bit [13]: 1 pull功能                                        
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 010 R0/4驱动能力              
	 *bit [0]: 0 低转换率                     
	 */
    //3 配置PWM时钟元
    PWM1->PWMCR = 0;
    PWM1->PWMCR |= (1 << 16) | (65 << 4) | (1 << 26);//配置PWM输出时钟
    pwm_setperiod_value(PWM1 , 1000); //PWM频率 = 1k
    printf("PWM时钟配置完毕3\r\n");
    //4 配置默认占空比
    for(i = 0; i < 4; i++){
        pwm_setduty(PWM1 ,50); // 连续写入4次，把FIFO写满
    }
    printf("初始占空比配置为50%%\r\n");
    //5 使能PWM相关中断
    PWM1->PWMIR |= 1 << 0; //时能FIFO空中断
    system_register_irqhandler(PWM1_IRQn ,pwm1_irqhandler ,NULL);
    GIC_EnableIRQ(PWM1_IRQn);//开启PWM中断
    PWM1->PWMSR = 0; //写1清0
    printf("PWM中断配置完毕\r\n");

    //6 开启PWM
    PWM1-> PWMCR |= 1;

    printf("LCD背光初始化完毕\r\n");
}

/*设置PWM的周期*/
void pwm_setperiod_value(PWM_Type *base , uint16_t value){
    uint16_t period;
    if(value < 2)
        period = 2;
    else
        period = value - 2;
    base->PWMPR = (period & 0xffff);
}

/*PWM占空比设置*/
void pwm_setduty(PWM_Type *base , uint16_t value){
    uint16_t period; //周期
    uint16_t sample;//采样率

    back_light_dev.pwm_duty = value;
    period = base->PWMPR + 2;//获取周期
    sample = (period * value / 100); //获取采样周期 注意 sample要开启浮点运算才对 因为其使用 * / 
    base->PWMSAR = (sample & 0xffff);
}

void pwm1_irqhandler(unsigned int gicciar , void *param){
    if(PWM1->PWMSR & (1 << 3)){//触发fifo空中断
        printf("FIFO空触发,重新写入占空比\r\n");
        pwm_setduty(PWM1 , back_light_dev.pwm_duty);
        PWM1->PWMSR |= (1 << 3); //中断标志位清0
    }
    /*清除中断标志位*/
    //gpio_clearflag(GPIO1 , 8);
}

/*利用LCD触摸滑动实现调控屏幕亮度*/
void change_backlight(void){
    
    
}

/*PWM限副*/
void pwm_limit(void){
    if(back_light_dev.pwm_duty > 100)
        back_light_dev.pwm_duty = 100;
}