#ifndef __BSP_BACKLIGHT_H__
#define __BSP_BACKLIGHT_H__
#include "imx6ul.h"
#include "bsp_int.h"
#include "stdio.h"
#include "bsp_gpio.h"
#include "bsp_ft5426.h"

/*LCD背光信息配置*/
struct backlight_dev_str{
    uint8_t pwm_duty; //占空比 0 - 100

};
extern struct backlight_dev_str back_light_dev;

void backlight_init(void);

void pwm_setperiod_value(PWM_Type *base , uint16_t value);
void pwm_setduty(PWM_Type *base , uint16_t value);
void pwm1_irqhandler(unsigned int gicciar , void *param);
void change_backlight(void);
void pwm_limit(void);


#endif // !__BSP_BACKLIGHT_H__
