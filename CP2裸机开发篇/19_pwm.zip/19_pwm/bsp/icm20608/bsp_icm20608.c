#include "bsp_icm20608.h"
#include "bsp_delay.h"

struct icm20608_dev_struc icm20608_dev; //传感器得到的数据在该结构体中 
/*初始化ICM20608*/
void init_icm20608(void) {
    uint8_t regval;
    printf("开始ICM20608器件初始化\r\n");
    //1 SPI引脚初始化
    /* 1、初始化IO复用*/
	IOMUXC_SetPinMux(IOMUXC_UART2_RX_DATA_ECSPI3_SCLK,0); //复用位SPI_CLK		
	IOMUXC_SetPinMux(IOMUXC_UART2_CTS_B_ECSPI3_MOSI,0); //复用位SPI_MOSI
    IOMUXC_SetPinMux(IOMUXC_UART2_RTS_B_ECSPI3_MISO,0);
    IOMUXC_SetPinMux(IOMUXC_UART2_TX_DATA_GPIO1_IO20,0); //CS片选信号
	/* 2、、配置IO属性	
	 *bit 16:0 HYS关闭
	 *bit [15:14]: 00 默认下拉
	 *bit [13]: 0 kepper功能
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 110 R0/6驱动能力
	 *bit [0]: 0 低转换率
	 */
	IOMUXC_SetPinConfig(IOMUXC_UART2_RX_DATA_ECSPI3_SCLK,0X10B1);
    IOMUXC_SetPinConfig(IOMUXC_UART2_CTS_B_ECSPI3_MOSI,0X10B1);
    IOMUXC_SetPinConfig(IOMUXC_UART2_RTS_B_ECSPI3_MISO,0X10B1);
    IOMUXC_SetPinConfig(IOMUXC_UART2_TX_DATA_GPIO1_IO20,0X10B1);
    gpio_pin_config_t cs_config;
    cs_config.direction = kGPIO_DigitalOutput;
    cs_config.outputLogic = 0;//默认CS为底，选中端口
    gpio_init(GPIO1 , 20 , &cs_config);
    printf("ICM20608器件IO初始化完毕\r\n");

    //2 SPI控制器初始化
    spi_init(ECSPI3);

    //3 复位ICM20608 关闭睡眠模式
    icm_20608_write_reg(ICM20_PWR_MGMT_1, 0x80);		/* 复位，复位后为0x40,睡眠模式 			*/
	printf("复位ICM20608成功\r\n");
    delay_ms(50);
	icm_20608_write_reg(ICM20_PWR_MGMT_1, 0x01);		/* 关闭睡眠，自动选择时钟 					*/
	printf("唤醒ICM20608\r\n");
    delay_ms(50);

    //4 ICM20608初始化
    regval = icm_20608_read_reg(ICM20_WHO_AM_I);
    if(regval == ICM20608G_ID)
        printf("识别成功 为ICM20608G\r\n");
    else if(regval == ICM20608D_ID)
        printf("识别成功 为ICM20608G\r\n");
    else 
        printf("识别失败\r\n");
    

    //5 配置ICM20608相关参数
    printf("开始配置ICM20608传感器参数\r\n");
    delay_ms(1000);
    icm_20608_write_reg(ICM20_SMPLRT_DIV, 0x00); 	/* 输出速率是内部采样率					*/
	icm_20608_write_reg(ICM20_GYRO_CONFIG, 0x18); 	/* 陀螺仪±2000dps量程 				*/
    icm_20608_write_reg(ICM20_ACCEL_CONFIG, 0x18); 	/* 加速度计±16G量程 					*/
	icm_20608_write_reg(ICM20_CONFIG, 0x04); 		/* 陀螺仪低通滤波BW=20Hz 				*/
	icm_20608_write_reg(ICM20_ACCEL_CONFIG2, 0x04); 	/* 加速度计低通滤波BW=21.2Hz 			*/
	icm_20608_write_reg(ICM20_PWR_MGMT_2, 0x00); 	/* 打开加速度计和陀螺仪所有轴 				*/
	icm_20608_write_reg(ICM20_LP_MODE_CFG, 0x00); 	/* 关闭低功耗 						*/
	icm_20608_write_reg(ICM20_FIFO_EN, 0x00);		/* 关闭FIFO	*/
    printf("ICM20608初始化完毕\r\n");
}
    		


/*ICM20608 SPI读数据*/
uint8_t icm_20608_read_reg(uint8_t reg) {
    //printf("向ICM20608读取数据\r\n");
    uint8_t reg_val;
    uint8_t dummy = 0xff;
    reg |= 0x80;  //bit7值1表示读取数据 参考ICM20608数据手册p28
    IMC20608_CSN(0); //CS拉底 选中芯片
    spich0_readwrite_byte(ECSPI3 , reg);//发送访问的寄存器地址
    reg_val = spich0_readwrite_byte(ECSPI3 , dummy); /*进行一次读操作 目的是
                                                       给从机提供一次通信时钟         
                                                                */
    IMC20608_CSN(1);//拉高 停止访问
    //printf("读取的信息为：%#x\r\n" , reg_val);
    return reg_val; 
}


/*ICM20608 SPI写数据*/
void icm_20608_write_reg(uint8_t reg , uint8_t val){
    //printf("向ICM20608写入数据\r\n");
    reg &= ~0x80;  //bit7值0表示写数据 参考ICM20608数据手册p28
    IMC20608_CSN(0); //CS拉底 选中芯片
    spich0_readwrite_byte(ECSPI3 , reg);//发送访问的寄存器地址
    spich0_readwrite_byte(ECSPI3 , val); //写入的数据
    IMC20608_CSN(1);//拉高 停止访问
    //printf("写入的数据为:%d\r\n", val);
}


/*连续读ICM20608的寄存器值*/
void icm_20608_read_len(uint8_t reg , uint8_t *buf , uint8_t len){
    uint8_t i;
    reg |= 0x80;  //bit7值1表示读取数据 参考ICM20608数据手册p28
    IMC20608_CSN(0); //CS拉底 选中芯片
    spich0_readwrite_byte(ECSPI3 , reg);//发送访问的寄存器地址
    for(i = 0; i < len; i++){
        *(buf + i) = spich0_readwrite_byte(ECSPI3 , 0xff); //寄存器支持自增
    }
    IMC20608_CSN(1);//拉高 停止访问
}
/*
 * @description : 获取陀螺仪的分辨率
 * @param		: 无
 * @return		: 获取到的分辨率
 */
float icm20608_gyro_scaleget(void)
{
	unsigned char data;
	float gyroscale;
	
	data = (icm_20608_read_reg(ICM20_GYRO_CONFIG) >> 3) & 0X3;
	switch(data) {
		case 0: 
			gyroscale = 131;
			break;
		case 1:
			gyroscale = 65.5;
			break;
		case 2:
			gyroscale = 32.8;
			break;
		case 3:
			gyroscale = 16.4;
			break;
	}
	return gyroscale;
}

/*
 * @description : 获取加速度计的分辨率
 * @param		: 无
 * @return		: 获取到的分辨率
 */
unsigned short icm20608_accel_scaleget(void)
{
	unsigned char data;
	unsigned short accelscale;
	
	data = (icm_20608_read_reg(ICM20_ACCEL_CONFIG) >> 3) & 0X3;
	switch(data) {
		case 0: 
			accelscale = 16384;
			break;
		case 1:
			accelscale = 8192;
			break;
		case 2:
			accelscale = 4096;
			break;
		case 3:
			accelscale = 2048;
			break;
	}
	return accelscale;
}

/*获取ICM20608数据*/
void icm20608_getdata(void){
    //0配置参数
    float gyroscale; //角速度精度
	unsigned short accescale; //加速度精度
    gyroscale = icm20608_gyro_scaleget();
	accescale = icm20608_accel_scaleget();
    //1读取数据
    uint8_t data[14];//暂存数据
    icm_20608_read_len(ICM20_ACCEL_XOUT_H , data , 14);//读取从ICM20_ACCEL_XOUT_H连续14个字节的数据
    //2进行数据整理
    /*加速度组*/
    icm20608_dev.accel_x_adc = (int16_t)((data[0] << 8) | (data[1]));
    icm20608_dev.accel_y_adc = (int16_t)((data[2] << 8) | (data[3]));
    icm20608_dev.accel_z_adc = (int16_t)((data[4] << 8) | (data[5]));
    /*温度*/
    icm20608_dev.temp_adc    = (signed short)((data[6] << 8) | data[7]); 
    /*角速度组*/
	icm20608_dev.gyro_x_adc  = (signed short)((data[8] << 8) | data[9]); 
	icm20608_dev.gyro_y_adc  = (signed short)((data[10] << 8) | data[11]);
	icm20608_dev.gyro_z_adc  = (signed short)((data[12] << 8) | data[13]);
    //3 将ADC数据转换从实际值
    /*现将数据扩大100倍，因为串口不支持浮点数输出*/
    /*不同的设置范围对应不同的系数详见ICM数据手册p7 对照初始化时的对应精度*/
    icm20608_dev.gyro_x_act = ((float)(icm20608_dev.gyro_x_adc)  / gyroscale) * 100;
	icm20608_dev.gyro_y_act = ((float)(icm20608_dev.gyro_y_adc)  / gyroscale) * 100;
	icm20608_dev.gyro_z_act = ((float)(icm20608_dev.gyro_z_adc)  / gyroscale) * 100;

	icm20608_dev.accel_x_act = ((float)(icm20608_dev.accel_x_adc) / accescale) * 100;
	icm20608_dev.accel_y_act = ((float)(icm20608_dev.accel_y_adc) / accescale) * 100;
	icm20608_dev.accel_z_act = ((float)(icm20608_dev.accel_z_adc) / accescale) * 100;

	icm20608_dev.temp_act = (((float)(icm20608_dev.temp_adc) - 25 ) / 326.8 + 25) * 100;

}
