#include "bsp_myfunction.h"

void handle_num(int num , struct numFomat *handle) {
    int i = 0 ,  j = 0;
    handle->flag = 0;
    handle->integer_part = 0;
    handle->float_part[2] = '0';
    handle->float_part[1] = '0';
    //判断num正负
    if (num < 0) {
        num = -num;
        handle->flag = 1;
    }
    //取位
    while (num) {
        numBuf[i] = num % 10;
        num /= 10;
        i++;
    }
    if (i == 0) {//说明num == 0
        return;
    }
    //按规定存放到指定数据中
    for (j = i - 1; ~j; j--) {
        if (j > 1) {//整数部分
            handle->integer_part = handle->integer_part * 10 + numBuf[j];
        }
    }
    //小数部分由于前导0的存在，单独处理
    handle->float_part[2] = (numBuf[1] + '0');
    handle->float_part[1] = (numBuf[0] + '0');
    handle->float_part[0] = '\0';
}