#include "bsp_clk.h"

/***************************************************************
Copyright © zuozhongkai Co., Ltd. 1998-2019. All rights reserved.
文件名	: 	 bsp_clk.c
作者	   : 左忠凯
版本	   : V1.0
描述	   : 系统时钟驱动。
其他	   : 无
论坛 	   : www.wtmembed.com
日志	   : 初版V1.0 2019/1/4 左忠凯创建
***************************************************************/

/*
 * @description	: 使能I.MX6U所有外设时钟
 * @param 		: 无
 * @return 		: 无
 */
void clk_enable(void)
{
	CCM->CCGR0 = 0XFFFFFFFF;
	CCM->CCGR1 = 0XFFFFFFFF;
	CCM->CCGR2 = 0XFFFFFFFF;
	CCM->CCGR3 = 0XFFFFFFFF;
	CCM->CCGR4 = 0XFFFFFFFF;
	CCM->CCGR5 = 0XFFFFFFFF;
	CCM->CCGR6 = 0XFFFFFFFF;
}

/*初始化时钟*/
void IMX_ARM_clk_init(int clk_switch)
{
	int pll_arm_fre = 0, arm_dev = 0;
	volatile uint32_t reg;
	if(!clk_switch) 
		return;
	else if(clk_switch == 1){ //528Mhz
		pll_arm_fre = 88;
		arm_dev = 1;
	}
	else if(clk_switch == 2){ //600Mhz
		pll_arm_fre = 50;
        arm_dev = 0;
	}
	else if(clk_switch == 3){
		pll_arm_fre = 66;
        arm_dev = 0;
	}

	/*修改主频*/
    //1.切换到主频时钟输入至step_clk
	if(((CCM->CCSR >> 2) & 0X1) == 0) {
		//当前时钟输入是pll1_main_clk（主频）
		CCM->CCSR &= ~(1 << 8); //选择主频输入源为step_clk = 24Mhz
		CCM->CCSR |= (1 << 2); //切换主频输入
	}

    //2.设置PLL主频为1056Mhz
	 CCM_ANALOG->PLL_ARM |= (pll_arm_fre & 0X7F); //配频为固定频率 具体见公式
	 CCM_ANALOG->PLL_ARM |= (1 << 13);//使能时钟输出

	//3.设置主频输出源头的pll1_main_clk（主频）的分频系数
	CCM->CACRR = arm_dev; //注意，这里1就是2分频，默认会有一次二分频 即 主频为 1056 / 2 = 528

	//4.切换回pll1_main_clk为主频的输出源
	CCM->CCSR &= ~(1 << 2);

    /*修改PLL2及其PLD*/
	reg = CCM_ANALOG->PFD_528; //读出PLL2寄存器的值
	reg &= ~(0x3f3f3f3f); //每字节保留高2位的值，清零低位
	reg |= (528 * 18 / 297) << 24; //PLL2_PFD3 = 297Mhz
	reg |= (528 * 18 / 396) << 16;
    reg |= (528 * 18 / 594) << 8;
    reg |= (528 * 18 / 352) << 0;
	CCM_ANALOG->PFD_528 = reg;

	/*修改PLL3及其PLD*/
	reg = 0;
	reg = CCM_ANALOG->PFD_480;
	reg &= ~(0x3f3f3f3f);
	reg |= (480 * 18 / 454) << 24; //454.7Mhz
    reg |= (528 * 18 / 508) << 16; //508.4
    reg |= (528 * 18 / 540) << 8; 
    reg |= (528 * 18 / 720) << 0;
    CCM_ANALOG->PFD_480 = reg;

	/*修改AHB及一些其他外舍时钟*/
	//1 AHB时钟 132MHZ
	reg = CCM->CBCMR;
	reg &= ~(3 << 18);
	reg |= (1 << 18); //选择PLL2_PFD2作为数字AHB时钟来源
	reg &= ~(1 << 25);
	CCM->CBCMR = reg;
	while(CCM->CDHIPR & (1 << 5)){}; //等待握手信号完成 使信号同步
	
	reg = CCM->CBCDR;
    reg &= ~(7 << 10);
	reg |= (1 << 11); //PLL2_PFD2三分频为AHB时钟频率
	CCM->CBCDR = reg; //一次性写入 以防多次直接写寄存器失败
	while(CCM->CDHIPR & (1 << 1)){}; //等待握手信号完成 使信号同步

	//2 AHB时钟设为132Mhz后 利用AHB时钟修改其他外设时钟频率
	//设置PERCLK_CLK_ROOT为66Mhz
	reg = CCM->CBCDR;
	reg &= ~(3 << 8);
	reg |= (1 << 8); //2分频 AHB作为来源信号 PERCLK_CLK_ROOT = 66Mhz
	CCM->CBCDR = reg;

	reg = CCM->CSCMR1;
	reg &= ~(1 << 6); // 选择分频的来源信号为PERCLK_CLK_ROOT信号
	reg &= ~(0x3f << 0);//注意 寄存器是5位，但文档写的时候只写了三位
	reg |= (0 << 0); //1分频来源信号
	CCM->CSCMR1 = reg;
}
