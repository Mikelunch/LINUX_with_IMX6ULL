#include "bsp_ft5426.h"
struct ft5426_dev_struc ft5426_dev;
/*初始化触摸屏*/
void ft5426_init(void){
  uint8_t reg_val[2];//存储读出的值
  uint16_t chipId; //芯片ID
  int i;
	for( i = 0; i < 5; i++ )
	{	/* 避免编译器自动赋值 */
		ft5426_dev.x[i] = 0;
		ft5426_dev.y[i] = 0;
	}
  ft5426_dev.point_num = 0;
  printf("开始初始化ft5426触摸屏......\r\n");
  ft5426_dev.initfalg = FT5426_INIT_NOTFINISHED;
  //1 IO初始化
  IOMUXC_SetPinMux(IOMUXC_UART5_TX_DATA_I2C2_SCL,1);//I2C2_SCL	参数必须是1 强制IO输入为MUX_MOD定义的模式	
	IOMUXC_SetPinMux(IOMUXC_UART5_RX_DATA_I2C2_SDA,1);//I2C2_SDA		
	IOMUXC_SetPinMux(IOMUXC_GPIO1_IO09_GPIO1_IO09,0); //中断管脚
  IOMUXC_SetPinMux(IOMUXC_SNVS_SNVS_TAMPER9_GPIO5_IO09,0); //复位管脚

	/* 配置I2C相关IO属性	                   配置中断相关IO          配置复用IO
	 *bit 16:0 HYS关闭
	 *bit [15:14]: 01 上拉                    11： 上拉             00 默认下拉
	 *bit [13]: 1 pull功能                                         0：keeper功能
	 *bit [12]: 1 pull/keeper使能
	 *bit [11]: 0 关闭开路输出
	 *bit [7:6]: 10 速度100Mhz
	 *bit [5:3]: 110 R0/6驱动能力              00：关闭输出
	 *bit [0]: 0 低转换率                     
	 */
	IOMUXC_SetPinConfig(IOMUXC_UART5_TX_DATA_I2C2_SCL,0X70B0);
  IOMUXC_SetPinConfig(IOMUXC_UART5_RX_DATA_I2C2_SDA,0X70B0);
  IOMUXC_SetPinConfig(IOMUXC_GPIO1_IO09_GPIO1_IO09,0XF080);
  IOMUXC_SetPinConfig(IOMUXC_SNVS_SNVS_TAMPER9_GPIO5_IO09,0X10B0);
  printf("ft5426IO配置成功.....\r\n");  
  /*中断IO配置成双边沿触发*/
  gpio_pin_config_t cint_config;
  cint_config.direction = kGPIO_DigitalInput;
  cint_config.gpio_interrput_mode = kGPIO_IntRisingOrFallingEdge;//上升下降均触发   
  gpio_init(GPIO1 , 9 , &cint_config);
		
  GIC_EnableIRQ(GPIO1_Combined_0_15_IRQn);//使能IQR;//开启外部中断
  system_register_irqhandler(GPIO1_Combined_0_15_IRQn ,(system_irq_handler_t)gpio1_io09_irqhandler ,NULL);
  gpio_interrput_enable(GPIO1 , 9 , 1); //开启GPIO中断

  /*复位IO配置*/
  gpio_pin_config_t ctrest_config;
  ctrest_config.direction = kGPIO_DigitalOutput;
  ctrest_config.outputLogic = 1;//默认输出高电平
  ctrest_config.gpio_interrput_mode = kGPIO_NoIntmode;
  gpio_init(GPIO5 , 9 , &ctrest_config);

  /*初始化好后先复位*/
  printf("开始复位ft5426IO\r\n");
  gpio_pinwrite(GPIO5 , 9 , 0);//拉底复位
	delay_ms(50);
  gpio_pinwrite(GPIO5 , 9 , 1);
  delay_ms(50);
  printf("复位ft5426IO完毕\r\n");
  printf("ft5426IO初始化完毕\r\n");

  //2 I2C初始化
  printf("FT6426初始化I2C2\r\n");
  init_i2c(I2C2);
  printf("FT6426初始化I2C2完毕\r\n");

  //3 FT6426配置
  FT5426_WriteByte(FT5426_ADDR , FT5426_DEVICE_MODE, 0x0); //配置FT5426工作在正常模式
  FT5426_WriteByte(FT5426_ADDR , FT5426_IDG_MODE, 0x1); //设置触发模式为中断模式  

  FT5426_Read_Len(FT5426_ADDR , FT5426_IDGLIB_VERSION, 2 , reg_val);
  chipId = (((uint16_t)(reg_val[0] << 8 )) | reg_val[1]);
  printf("FT5426_IDGLIB_VERSION = %#x\r\n",chipId);
  if(chipId == 0x0){
    printf("识别成功,为FT5426C版本\r\n");
  }
  else{
    printf("识别失败,检测芯片是否复位");
  }
    
  ft5426_dev.initfalg = FT5426_INIT_FINISHED;
  ft5426_dev.intflag = 0;
}

/*
  * @description	 : GPIO外部中断服务函数
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void gpio1_io09_irqhandler(unsigned int gicciar , void *param){
  if(ft5426_dev.initfalg == FT5426_INIT_FINISHED){ //触摸屏有接触
    FT5426_read_tpcoord();
  }
  /*清除中断标志位*/
  gpio_clearflag(GPIO1 , 9);
}


/*
  * @description	 : 读FT5426寄存器一字节数据
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
uint8_t FT5426_ReadByte(uint8_t addr, uint8_t reg){
    uint8_t data;
    struct i2c_transfer xfer;
    xfer.slaveAddress = addr;
    xfer.direction = KI2c_Read;
    xfer.subaddress = reg;
    xfer.subaddressSize = 1;
    xfer.data = &data;
    xfer.dataSize = 1;
    i2c_master_transfer(I2C2, &xfer);
    return data;
}

/*
  * @description	 : 写FT5426寄存器一字节数据
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
uint8_t FT5426_WriteByte(uint8_t addr, uint8_t reg , uint8_t data){
    struct i2c_transfer xfer;
    xfer.slaveAddress = addr;
    xfer.direction = KI2c_Write;
    xfer.subaddress = reg;
    xfer.subaddressSize = 1;
    xfer.data = &data;
    xfer.dataSize = 1;
    return i2c_master_transfer(I2C2, &xfer);
}


/*
  * @description	 : 连续读FT5426寄存器长度数据
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void FT5426_Read_Len(uint8_t addr , uint8_t reg , uint32_t len , uint8_t *buf){
    struct i2c_transfer xfer;
    xfer.slaveAddress = addr;
    xfer.direction = KI2c_Read;
    xfer.subaddress = reg;
    xfer.subaddressSize = 1;
    xfer.data = buf;
    xfer.dataSize = len;
    i2c_master_transfer(I2C2, &xfer);
}

/*
  * @description	 : 读取电容触摸坐标信息
  * @param - base	 : 要输出的的GPIO组。
  * @param - pin	 : 要输出的GPIO脚号。
  * @return 		 : 无
*/
void FT5426_read_tpcoord(void){
  uint8_t reg_buf[FT5426_XYCOORDREG_NUM];
  uint8_t i = 0;
  ft5426_dev.point_num = FT5426_ReadByte(FT5426_ADDR , FT5426_TD_STATUS);//读取当前屏幕接触点数量
  /*将所有点的信息读取出来*/
  FT5426_Read_Len(FT5426_ADDR , FT5426_TOUCH1_XH , FT5426_XYCOORDREG_NUM ,reg_buf);
  for(i = 0; i < ft5426_dev.point_num; i++){
    uint8_t *bufP = &reg_buf[i * 6];  //每个触点有6个寄存器
    ft5426_dev.x[i] = ((bufP[2] << 8) | (bufP[3])) & 0xfff; //连续进入中断 高位数据只有前4位有效
    ft5426_dev.y[i] = ((bufP[0] << 8) | (bufP[1])) & 0xfff; //注意 屏幕像素的座标点应根据实际情况作出判断 坐标轴的建立的是相对的
    //type = bufP[0] >> 6; //获取事件类型
    // if(type == FT5426_TOUCH_EVENT_DOWN){
    //   printf("FT5426_TOUCH_EVENT_DOWN\r\n");
    // }
    // else if(type == FT5426_TOUCH_EVENT_UP){
    //   printf("FT5426_TOUCH_EVENT_UP\r\n");
    // }
    // else if(type == FT5426_TOUCH_EVENT_ON){
    //   printf("FT5426_TOUCH_EVENT_ON\r\n");
    // }
    // else{
    //   printf("FT5426_TOUCH_NOTHING\r\n");
    // }
    
  }
} 