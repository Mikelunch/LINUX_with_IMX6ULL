#include "bsp_clk.h"
#include "bsp_delay.h"
#include "bsp_led.h"
#include "bsp_beep.h"
#include "bsp_key.h"
#include "bsp_int.h"
#include "bsp_exti.h"
#include "bsp_epit.h"
#include "bsp_gpio.h"
#include "bsp_uart.h"
#include "bsp_lcd.h"
#include "bsp_lcdapi.h"
#include "bsp_rtc.h"
#include "bsp_ap3216c.h"
#include "bsp_i2c.h"
#include "stdio.h"
#include "bsp_icm20608.h"
#include "bsp_spi.h"
#include "bsp_myfunction.h"
#include "bsp_ft5426.h"

/*
 * @description	: 使能I.MX6U的硬件NEON和FPU 想要使用flaot类型必须打开
 * @param 		: 无
 * @return 		: 无
 * 详细参考资料<rence Manual ARMv7-A and ARMv7-R edition.pdf>
 * 同时，在C编译MakeFile中加入浮点运算编译
 */
 void imx6ul_hardfpu_enable(void)
{
	uint32_t cpacr;
	uint32_t fpexc;

	/* 使能NEON和FPU */
	cpacr = __get_CPACR();
	cpacr = (cpacr & ~(CPACR_ASEDIS_Msk | CPACR_D32DIS_Msk))
		   |  (3UL << CPACR_cp10_Pos) | (3UL << CPACR_cp11_Pos);
	__set_CPACR(cpacr);
	fpexc = __get_FPEXC();
	fpexc |= 0x40000000UL;	
	__set_FPEXC(fpexc);
}




/*
 * @description	: main函数
 * @param 		: 无
 * @return 		: 无
 */
int main(void)
{
	static uint8_t state = 1;
    uint8_t i;
	uint8_t gt_init_fail = 1;
	imx6ul_hardfpu_enable(); /*使能浮点						*/
	int_init();
	IMX_ARM_clk_init(ARM_CLK_528);			//初始化主频
	clk_enable();		/* 使能所有的时钟 			*/
	delay_init();        /* 使能GPT定时器的延时函数            */
	uart_init(UART1 , 115200);         /* 使能串口 			*/ 
	printf("\r\n\r\n -------------开始初始化-------------\r\n\r\n");
	led_init();			/* 初始化led 			*/
	beep_init();		/* 初始化beep	 		*/
	key_init();			/* 初始化key 			*/
 	exti_init(GPIO1 , 18); /* 初始化外部中断			*/
	epit_init(66,1e6);  /* 初始化EPIT定时器中断	 66分频 计数10^6 但并没有开始工作*/
	lcd_init();			/*屏幕初始化						*/
	my_lcd_config.forecolor = LCD_RED;
	my_lcd_config.backcolor = LCD_WHITE;
	AP3216C_Init();   /*传感器AP3216C初始化						*/
	init_icm20608();  /*传感器ICM20608初始化						*/
	ft5426_init();   /*传感器FT5426初始化						*/

	/*配置LCD显示参数 显示触摸信息*/
	my_lcd_config.forecolor = LCD_RED;
	
	lcd_show_string(50, 110, 400, 16, 16,	(char*)"TP Num	:");  
	lcd_show_string(50, 130, 200, 16, 16,	(char*)"Point0 X:");  
	lcd_show_string(50, 150, 200, 16, 16,	(char*)"Point0 Y:");  
	lcd_show_string(50, 170, 200, 16, 16,	(char*)"Point1 X:");  
	lcd_show_string(50, 190, 200, 16, 16,	(char*)"Point1 Y:");  
	lcd_show_string(50, 210, 200, 16, 16,	(char*)"Point2 X:");  
	lcd_show_string(50, 230, 200, 16, 16,	(char*)"Point2 Y:");  
	lcd_show_string(50, 250, 200, 16, 16,	(char*)"Point3 X:");  
	lcd_show_string(50, 270, 200, 16, 16,	(char*)"Point3 Y:");  
	lcd_show_string(50, 290, 200, 16, 16,	(char*)"Point4 X:");  
	lcd_show_string(50, 310, 200, 16, 16,	(char*)"Point4 Y:");  
	my_lcd_config.forecolor = LCD_BLUE;


	printf("\r\n\r\n------进入主循环------\r\n");
	while(1)					
	{
		if(gt_init_fail==1) {
			lcd_shownum(50 + 72, 110, ft5426_dev.point_num , 1, 16);
			lcd_shownum(50 + 72, 130, ft5426_dev.x[0], 5, 16);
			lcd_shownum(50 + 72, 150, ft5426_dev.y[0], 5, 16);
			lcd_shownum(50 + 72, 170, ft5426_dev.x[1], 5, 16);
			lcd_shownum(50 + 72, 190, ft5426_dev.y[1], 5, 16);
			lcd_shownum(50 + 72, 210, ft5426_dev.x[2], 5, 16);
			lcd_shownum(50 + 72, 230, ft5426_dev.y[2], 5, 16);
			lcd_shownum(50 + 72, 250, ft5426_dev.x[3], 5, 16);
			lcd_shownum(50 + 72, 270, ft5426_dev.y[3], 5, 16);
			lcd_shownum(50 + 72, 290, ft5426_dev.x[4], 5, 16);
			lcd_shownum(50 + 72, 310, ft5426_dev.y[4], 5, 16);
		} 
		//else {
		// 	lcd_shownum(50 + 72, 110, gt9147_dev.point_num , 1, 16);
		// 	lcd_shownum(50 + 72, 130, gt9147_dev.x[0], 5, 16);
		// 	lcd_shownum(50 + 72, 150, gt9147_dev.y[0], 5, 16);
		// 	lcd_shownum(50 + 72, 170, gt9147_dev.x[1], 5, 16);
		// 	lcd_shownum(50 + 72, 190, gt9147_dev.y[1], 5, 16);
		// 	lcd_shownum(50 + 72, 210, gt9147_dev.x[2], 5, 16);
		// 	lcd_shownum(50 + 72, 230, gt9147_dev.y[2], 5, 16);
		// 	lcd_shownum(50 + 72, 250, gt9147_dev.x[3], 5, 16);
		// 	lcd_shownum(50 + 72, 270, gt9147_dev.y[3], 5, 16);
		// 	lcd_shownum(50 + 72, 290, gt9147_dev.x[4], 5, 16);
		// 	lcd_shownum(50 + 72, 310, gt9147_dev.y[4], 5, 16);
		// }
		delay_ms(10);
		i++;
	
		if(i == 50)
		{	
			i = 0;
			state = !state;
			led_switch(LED0,state , 0); 
		}
	}
	return 0;
}
