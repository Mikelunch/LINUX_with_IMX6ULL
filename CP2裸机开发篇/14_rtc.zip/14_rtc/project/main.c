#include "bsp_clk.h"
#include "bsp_delay.h"
#include "bsp_led.h"
#include "bsp_beep.h"
#include "bsp_key.h"
#include "bsp_int.h"
#include "bsp_exti.h"
#include "bsp_epit.h"
#include "bsp_gpio.h"
#include "bsp_uart.h"
#include "bsp_lcd.h"
#include "bsp_lcdapi.h"
#include "bsp_rtc.h"
#include "stdio.h"

/*
 * @description	: main函数
 * @param 		: 无
 * @return 		: 无
 */
int main(void)
{
	char stdbuf[100];
	static uint8_t state = 1;
	my_lcd_config.forecolor = LCD_RED; 
	struct rtc_datetime cur_data;
	cur_data.day = 25 , cur_data.month = 5 , cur_data.year = 2024;
	cur_data.hour = 19 , cur_data.minute = 50 , cur_data.second = 0;

	int_init();
	IMX_ARM_clk_init(ARM_CLK_528);			//初始化主频
	clk_enable();		/* 使能所有的时钟 			*/
	delay_init();        /* 使能GPT定时器的延时函数            */
	uart_init(UART1 , 115200);         /* 使能串口 			*/ 
	led_init();			/* 初始化led 			*/
	beep_init();		/* 初始化beep	 		*/
	key_init();			/* 初始化key 			*/
 	exti_init(GPIO1 , 18); /* 初始化外部中断			*/
	epit_init(66,1e6);  /* 初始化EPIT定时器中断	 66分频 计数10^6 但并没有开始工作*/
	lcd_init();			/*屏幕初始化						*/
	//rtc_init();			/*使能RTC时钟						*/
	//rtc_setdatetime(&cur_data);  /*设置rtc时间*/
	printf("\r\n初始化rtc时间结束\r\n");
	

	printf("Current Time is \r\n");
	my_lcd_config.forecolor = LCD_RED;	
	while(1)			
	{		
		rtc_getdatetime(&cur_data);
		sprintf(stdbuf,"%d/%d/%d %d:%d:%d",cur_data.year, cur_data.month,
					 cur_data.day, cur_data.hour, 
					cur_data.minute, cur_data.second);
		lcd_fill(50,110, 300,130, my_lcd_config.backcolor);
		lcd_show_string(50, 110, 250, 16, 16,(char*)stdbuf);  /* 显示字符串 */
		printf("%d/%d/%d %d:%d:%d\r\n",cur_data.year, cur_data.month,
					 cur_data.day, cur_data.hour, 
					cur_data.minute, cur_data.second);

		state = !state;
		led_switch(LED0,state , 0);
		delay_ms(1000);	/* 延时一秒 */
	}
		
	return 0;
}
